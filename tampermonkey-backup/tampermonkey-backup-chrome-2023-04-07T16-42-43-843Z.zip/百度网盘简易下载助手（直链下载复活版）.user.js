// ==UserScript==
// @name         百度网盘简易下载助手（直链下载复活版）
// @namespace    http://bd.softxm.cn/bd/
// @version      1.5.6.1
// @antifeature  membership
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       软件小妹
// @match        *://pan.baidu.com/*
// @match        *://yun.baidu.com/*
// @run-at       document-idle
// @grant        unsafeWindow
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_openInTab
// @grant        GM_notification
// @grant        GM_xmlhttpRequest
// @connect      localhost
// @connect      127.0.0.1
// @connect      yyxxs.cn
// @connect      softxm.cn
// @connect      softxm.vip
// @connect      softxm001.club
// @connect      softxm002.club
// @connect      softxm003.club
// @connect      softxm004.club
// @connect      softxm005.club
// @connect      softxm006.club
// @connect      softxm007.club
// @connect      softxm008.club
// @connect      softxm009.club
// @connect      baidu.com
// ==/UserScript==
